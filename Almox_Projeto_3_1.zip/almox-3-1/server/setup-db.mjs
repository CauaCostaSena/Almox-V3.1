import mysql from 'mysql2/promise';
import {readFile} from 'node:fs/promises';
import {hashPassword} from './auth.mjs';

// Migração aditiva: rode com o servidor parado e backup prévio.
const database=process.env.DB_NAME;
if(!database||!/^[a-zA-Z0-9_]+$/.test(database))throw Error('Configure DB_NAME com letras, números e sublinhado.');
const conn=await mysql.createConnection({host:process.env.DB_HOST||'127.0.0.1',port:Number(process.env.DB_PORT||3306),user:process.env.DB_USER||'root',password:process.env.DB_PASSWORD??'',multipleStatements:true});
try{
 await conn.query(`CREATE DATABASE IF NOT EXISTS \`${database}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci; USE \`${database}\`; SET time_zone = '+00:00';`);
 await conn.query(await readFile(new URL('../database/schema.sql',import.meta.url),'utf8'));
 const [columns]=await conn.query('SHOW COLUMNS FROM usuarios');
 for(const name of ['pais','estado'])if(!columns.some(c=>c.Field===name))await conn.query(`ALTER TABLE usuarios ADD COLUMN ${name} CHAR(2) NULL`);
 // Localização legada permanece NULL, sem inventar dados de funcionários.
 const id='11111111-1111-1111-1111-111111111111';
 const [owners]=await conn.execute('SELECT id FROM usuarios WHERE email=?',['admin@almox.est']);
 if(owners.length&&owners[0].id!==id)throw Error('E-mail admin pertence a outro registro. Revise manualmente; nenhum usuário será promovido.');
 await conn.beginTransaction();
 try{
  const hash=await hashPassword('admin$777');
  await conn.execute("INSERT INTO usuarios(id,nome,email,perfil,conta_sistema,senha_hash) VALUES(?,?,?,'admin',1,?) ON DUPLICATE KEY UPDATE senha_hash=?,perfil='admin',conta_sistema=1",[id,'Administrador','admin@almox.est',hash,hash]);
  await conn.execute('DELETE FROM sessoes WHERE usuario_id=?',[id]);
  await conn.commit();
 }catch(e){await conn.rollback();throw e;}
 try{await conn.query('CREATE EVENT IF NOT EXISTS atualizar_idades ON SCHEDULE EVERY 1 DAY DO UPDATE usuarios SET idade=TIMESTAMPDIFF(YEAR,nascimento,DATE(UTC_TIMESTAMP()-INTERVAL 3 HOUR)) WHERE nascimento IS NOT NULL');}
 catch(e){if(e.code==='ER_SPECIFIC_ACCESS_DENIED_ERROR')console.warn('Sem privilégio EVENT: idade será atualizada pelo servidor.');else throw e;}
 console.log(`Banco ${database} atualizado. Produtos e funcionários preservados. Senha admin redefinida; sessões admin encerradas.`);
}finally{await conn.end();}
