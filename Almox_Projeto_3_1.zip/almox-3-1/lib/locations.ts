// Cadastro nacional: CPF e telefone brasileiro. Nunca aceitar localização livre.
export const countries = [{ code: "BR", name: "Brasil" }];
export const states = [
  "AC",
  "AL",
  "AP",
  "AM",
  "BA",
  "CE",
  "DF",
  "ES",
  "GO",
  "MA",
  "MT",
  "MS",
  "MG",
  "PA",
  "PB",
  "PR",
  "PE",
  "PI",
  "RJ",
  "RN",
  "RS",
  "RO",
  "RR",
  "SC",
  "SP",
  "SE",
  "TO",
];
export function locationInput(b: Record<string, unknown>) {
  const pais = String(b.pais ?? ""),
    estado = String(b.estado ?? "");
  if (pais !== "BR")
    throw Error(
      "Selecione Brasil como país. O cadastro atende funcionários no Brasil.",
    );
  if (!states.includes(estado))
    throw Error("Selecione um estado brasileiro válido.");
  return { pais, estado };
}
