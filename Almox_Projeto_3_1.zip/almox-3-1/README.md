# Almox 3.1

Controle de estoque escolar com React, Node.js e MySQL. Login obrigatório;
funcionários gerenciam produtos e administradores gerenciam funcionários.

## Começar

Leia [LEIA-ME.txt](LEIA-ME.txt), especialmente antes de atualizar banco existente.

```sh
npm ci
npm run setup:env
```

Confira `.env` e `.env.test`. Com MySQL ativo e backup dos dados existentes:

```sh
npm run db:setup
npm run build
npm start
```

Abra o endereço exibido no terminal. Não use Go Live.
Admin escolar: `admin@almox.est` / `admin$777`. Não exponha na internet.

## Organização

| Pasta | Conteúdo |
| --- | --- |
| app, components | Interface e estilos |
| lib | Validações compartilhadas e localidades permitidas |
| server | HTTP, autenticação, transações e preparação do banco |
| database | Estrutura SQL e banco completo em texto |
| tests | Unidade, integração, sistema e automação de aceitação |
| docs | Relatório único de revisão e documentação histórica |
| test-results | Saídas locais dos testes, não versionadas |

Baixe e abra [o relatório único](docs/Relatorio_Revisao.html) no navegador:
comparação de Pablo, correções, tabelas de testes e capturas incorporadas.
Documentos em `docs/arquivo-v3` são históricos; não use suas senhas/caminhos antigos.

## Validação

`npm test` executa unidade. Os demais testes exigem banco descartável terminado
em `_testes` e apagam seus registros. Consulte LEIA-ME para preparação e comandos.
O workflow **Validar Almox** executa as suítes com MySQL e Chromium isolados.
Uma execução automatizada não substitui o aceite do grupo cliente.
